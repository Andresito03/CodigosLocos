package com.example.incidencias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IncidenciasApplication {

	public static void main(String[] args) {
		SpringApplication.run(IncidenciasApplication.class, args);
	}
}