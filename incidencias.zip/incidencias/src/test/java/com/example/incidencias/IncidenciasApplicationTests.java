package com.example.incidencias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IncidenciasApplicationTests {

	@Test
	void contextLoads() {
	}

}
